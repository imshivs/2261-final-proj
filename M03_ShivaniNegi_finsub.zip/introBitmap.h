
//{{BLOCK(introBitmap)

//======================================================================
//
//	introBitmap, 254x192@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 49152 = 49664
//
//	Time-stamp: 2016-11-21, 16:34:52
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_INTROBITMAP_H
#define GRIT_INTROBITMAP_H

#define introBitmapBitmapLen 49152
extern const unsigned short introBitmapBitmap[24576];

#define introBitmapPalLen 512
extern const unsigned short introBitmapPal[256];

#endif // GRIT_INTROBITMAP_H

//}}BLOCK(introBitmap)
