
//{{BLOCK(collisionmapTemp)

//======================================================================
//
//	collisionmapTemp, 512x256@16, 
//	+ bitmap not compressed
//	Total size: 262144 = 262144
//
//	Time-stamp: 2016-11-22, 02:43:50
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_COLLISIONMAPTEMP_H
#define GRIT_COLLISIONMAPTEMP_H

#define collisionmapTempBitmapLen 262144
extern const unsigned short collisionmapTempBitmap[131072];

#endif // GRIT_COLLISIONMAPTEMP_H

//}}BLOCK(collisionmapTemp)
