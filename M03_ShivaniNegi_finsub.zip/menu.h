
//{{BLOCK(menu)

//======================================================================
//
//	menu, 240x160@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 38400 = 38912
//
//	Time-stamp: 2016-11-21, 17:05:41
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_MENU_H
#define GRIT_MENU_H

#define menuBitmapLen 38400
extern const unsigned short menuBitmap[19200];

#define menuPalLen 512
extern const unsigned short menuPal[256];

#endif // GRIT_MENU_H

//}}BLOCK(menu)
